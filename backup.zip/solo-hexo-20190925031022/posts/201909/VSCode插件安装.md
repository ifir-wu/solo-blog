title: VSCode插件安装
date: '2019-09-25 03:00:09'
updated: '2019-09-25 03:00:09'
tags: [Note]
permalink: /articles/2019/09/25/1569351609054.html
---
# VSCode插件安装

## 中文插件

1. 在插件商店中输入`language`关键词，找到`中文（简体）`，点击`Install`安装（其他插件安装的方法同理，且大部分插件安装后直接可使用，无需配置）。

![1566962350927](E:\markdown\image\VSCode中文插件.png)

2. 使用快捷键组合【Ctrl+Shift+p】，在搜索框中输入`configure display language`，点击确定后，选择`zh-cn`重启即可。

   ![1566962627030](E:\markdown\image\VSCode配置中文插件.png)

## Python插件

1. 插件名：Python

   作者：Microsoft

   截图：![1566962981144](E:\markdown\image\VSCode的Python插件.png)

   备注：首次打开py文件会推荐安装，一般无需配置

   

2. 插件名：autoDocstring

   类型：Python注释

   描述：[官方描述](https://marketplace.visualstudio.com/items?itemName=njpwerner.autodocstring)

   截图：![1566976288879](E:\markdown\image\VSCode的autoDocstring插件.png)

   备注：一般无需配置。配置方法见官方描述。

3. 插件名：Python Preview

   类型：变量视图

   描述：展示Python中内置变量的值，方便有时候调试展示值。

   ![preview](E:\markdown\image\VSCode的Python Preview插件.jpg)

   截图：![1566976923285](E:\markdown\image\VSCode的Python Preview插件.png)

   备注：一般无需配置，右击.py文件标题即可查看视图。

   

4. 插件名：kite

   类型：AI智能代码补全，随时查看文档

   安装：

   （1）[官方](https://kite.com/)下载最新版

   （2）双击安装即可，插件在双击安装后启动的面板里选择安装。

   

## 外观配置

1. 插件名：vscode-icons

   类型：图标

   作者：VSCode Icons Team

   截图：![1566971642413](E:\markdown\image\VSCode的图标插件.png)

   备注：安装后会自动弹出`请选择图标主题`的提示，选择`vscode-icons`即可

   

2. 插件名：FiraCode

   类型：字体

   安装方式：

   （1）首先在[FiraCode](https://github.com/tonsky/FiraCode)的github页面下载字体，下载链接在`README.md`中间，找到如下图位置。

   ![img](E:\markdown\image\FiraCode插件下载)

   （2）把下载的压缩包解压，然后找到ttf文件夹，全部选中，右键安装即可

   （3）在VSCode中的配置

   ```json
     "editor.fontFamily": "'Fira Code', Consolas, 'Courier New', monospace",
                                  //添加上FiraCode字体
     "editor.fontLigatures": true,//开启连体字
   ```

   （4）如果配置完后，编辑器的内容没什么变化的话，重启一下就可以了。

   

3. 插件名：Bracket Pair Colorizer

   类型：括号

   作者：CoenraadS

   截图：![1566973401481](E:\markdown\image\VSCode括号插件.png)

   备注：一般无需配置，配置参考：[VSCode插件推荐 | Bracket Pair Colorizer：为代码中的括号添上一抹亮色](https://www.sohu.com/a/292946246_791833)

   

4. 插件名：Guides

   类型：缩进参考线

   描述：改变缩进参考线的颜色、样式、缩进空白的背景色等。

   截图：![1566974552705](E:\markdown\image\VSCode缩进参考线插件.png)

   备注：一般无需配置，推荐一个大神使用 Solarized Dark 主题时的配置如下。

   ```json
   {
       "guides.normal.color.dark": "rgba(91, 91, 91, 0.6)",
       "guides.normal.color.light": "rgba(220, 220, 220, 0.7)",
       "guides.active.color.dark": "rgba(210, 110, 210, 0.6)",
       "guides.active.color.light": "rgba(200, 100, 100, 0.7)",
       "guides.active.style": "dashed",
       "guides.normal.style": "dashed",
       "guides.stack.style": "dashed",
   }
   ```

5. 插件名：Better Comments

   类型：注释

   描述：对不同类型的注释会附加不同的颜色，更加方便区分！

   ![img](E:\markdown\image\VSCode的Better Comments插件.jpg)

   截图：![1566976539120](E:\markdown\image\VSCode的Better Comments插件.png)

   备注：一般无需配置

   

## 编程相关

1. 插件名：Code Spell Checker

   类型：拼写检查

   作者：Street Side Software

   描述：Code Spell Checker 强烈推荐，对大部分非英语母语又不想写出四不像变量名的程序员来说，正确识记拼写各种单词还是有不小的挑战，比模棱两可时需要去查在线词典不同的是，这款插件能实时的识别单词拼写是否有误，并给出提示，不少 bug 都是因为拼写错误导致的。

   截图：![1566975451347](E:\markdown\image\VSCode的代码拼写检查插件.png)

   备注：一般无需配置。



## 其他配置

1. 关于行末的空格、文件末尾的空行，以前需要使用插件来实现，现在直接修改 VSCode 内置配置即可实现。

   ```json
   {
       "files.trimTrailingWhitespace": true,
       "files.insertFinalNewline": true,
       "files.trimFinalNewlines": true
   }
   ```